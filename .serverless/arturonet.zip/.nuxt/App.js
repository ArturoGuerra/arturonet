import Vue from 'vue'
import NuxtLoading from './components/nuxt-loading.vue'

import '../node_modules/bulma/css/bulma.min.css'

import '../node_modules/colors.css/css/colors.min.css'

import '../assets/css/main.css'

import '../assets/css/navbar.css'

import '../assets/css/scroll.css'

import '../assets/css/gradients.css'

import '../assets/css/animate.css'


let layouts = {

  "_default": () => import('../layouts/default.vue'  /* webpackChunkName: "layouts/default" */).then(m => m.default || m)

}

let resolvedLayouts = {}

export default {
  head: {"titleTemplate":"%s - ArturoNet","meta":[{"charset":"utf-8"},{"name":"viewport","content":"width=device-width, initial-scale=1"},{"name":"theme-color","content":"#0C66A1"},{"name":"google-site-verification","content":"2QfKSG5ZPM__yZMnpIm5IJY1x52uhrgyVfbKCbOh0Xk"},{"hid":"description","name":"description","content":"Arturo's personal website"},{"property":"og:title","hid":"og:title","content":"ArturoNet"},{"property":"og:description","hid":"og:description","content":"Arturo's website"},{"property":"og:type","hid":"og:type","content":"website"},{"property":"og:image","hid":"og:image","content":"https:\u002F\u002Fwww.arturonet.com\u002Ffavicon.ico"},{"hid":"twitter:url","name":"twitter:url","content":"https:\u002F\u002Fwww.arturonet.com"},{"hid":"twitter:title","name":"twitter:title","content":"ArturoNet"},{"hid":"twitter:description","name":"twitter:description","content":"Arturo's website"},{"hid":"twitter:type","name":"twitter:type","content":"website"},{"hid":"twitter:image","name":"twitter:image","content":"https:\u002F\u002Fwww.arturonet.com\u002Ffavicon.ico"},{"hid":"twitter:url","name":"twitter:url","content":"https:\u002F\u002Fwww.arturonet.com"},{"hid":"twitter:card","name":"twitter:card","content":"summary"},{"hid":"twitter:creator","name":"twitter:creator","content":"@Ar2roGuerra"},{"hid":"apple-mobile-web-app-title","name":"apple-mobile-web-app-title","content":"ArturoNet"},{"hid":"mobile-web-app-capable","name":"mobile-web-app-capable","content":"yes"},{"hid":"author","name":"author","content":"Arturo Guerra"}],"link":[{"rel":"apple-touch-icon","sizes":"57x57","href":"https:\u002F\u002Fs3.amazonaws.com\u002Farturonet-static\u002Fapple-icon-57x57.png"},{"rel":"apple-touch-icon","sizes":"60x60","href":"https:\u002F\u002Fs3.amazonaws.com\u002Farturonet-static\u002Fapple-icon-60x60.png"},{"rel":"apple-touch-icon","sizes":"72x72","href":"https:\u002F\u002Fs3.amazonaws.com\u002Farturonet-static\u002Fapple-icon-72x72.png"},{"rel":"apple-touch-icon","sizes":"76x76","href":"https:\u002F\u002Fs3.amazonaws.com\u002Farturonet-static\u002Fapple-icon-76x76.png"},{"rel":"apple-touch-icon","sizes":"114x114","href":"https:\u002F\u002Fs3.amazonaws.com\u002Farturonet-static\u002Fapple-icon-114x114.png"},{"rel":"apple-touch-icon","sizes":"120x120","href":"https:\u002F\u002Fs3.amazonaws.com\u002Farturonet-static\u002Fapple-icon-120x120.png"},{"rel":"apple-touch-icon","sizes":"144x144","href":"https:\u002F\u002Fs3.amazonaws.com\u002Farturonet-static\u002Fapple-icon-144x144.png"},{"rel":"apple-touch-icon","sizes":"152x152","href":"https:\u002F\u002Fs3.amazonaws.com\u002Farturonet-static\u002Fapple-icon-152x152.png"},{"rel":"apple-touch-icon","sizes":"180x180","href":"https:\u002F\u002Fs3.amazonaws.com\u002Farturonet-static\u002Fapple-icon-180x180.png"},{"rel":"icon","type":"image\u002Fpng","sizes":"192x192","href":"https:\u002F\u002Fs3.amazonaws.com\u002Farturonet-static\u002Fandroid-icon-192x192.png"},{"rel":"icon","type":"image\u002Fpng","sizes":"32x32","href":"https:\u002F\u002Fs3.amazonaws.com\u002Farturonet-static\u002Ffavicon-32x32.png"},{"rel":"icon","type":"image\u002Fpng","sizes":"96x96","href":"https:\u002F\u002Fs3.amazonaws.com\u002Farturonet-static\u002Ffavicon-96x96.png"},{"rel":"icon","type":"image\u002Fpng","sizes":"16x16","href":"https:\u002F\u002Fs3.amazonaws.com\u002Farturonet-static\u002Ffavicon-16x16.png"},{"rel":"shortcut icon","type":"image\u002Fx-icon","href":"https:\u002F\u002Fs3.amazonaws.com\u002Farturonet-static\u002Ffavicon.ico"},{"rel":"manifest","href":"\u002F_nuxt\u002Fmanifest.c23e5320.json"}],"style":[],"script":[],"title":"arturonet","htmlAttrs":{"lang":"en"}},
  render(h, props) {
    const loadingEl = h('nuxt-loading', { ref: 'loading' })
    const layoutEl = h(this.layout || 'nuxt')
    const templateEl = h('div', {
      domProps: {
        id: '__layout'
      },
      key: this.layoutName
    }, [ layoutEl ])

    const transitionEl = h('transition', {
      props: {
        name: 'layout',
        mode: 'out-in'
      }
    }, [ templateEl ])

    return h('div',{
      domProps: {
        id: '__nuxt'
      }
    }, [
      loadingEl,
      transitionEl
    ])
  },
  data: () => ({
    layout: null,
    layoutName: ''
  }),
  beforeCreate () {
    Vue.util.defineReactive(this, 'nuxt', this.$options.nuxt)
  },
  created () {
    // Add this.$nuxt in child instances
    Vue.prototype.$nuxt = this
    // add to window so we can listen when ready
    if (typeof window !== 'undefined') {
      window.$nuxt = this
    }
    // Add $nuxt.error()
    this.error = this.nuxt.error
  },
  
  mounted () {
    this.$loading = this.$refs.loading
  },
  watch: {
    'nuxt.err': 'errorChanged'
  },
  
  methods: {
    
    errorChanged () {
      if (this.nuxt.err && this.$loading) {
        if (this.$loading.fail) this.$loading.fail()
        if (this.$loading.finish) this.$loading.finish()
      }
    },
    
    setLayout (layout) {
      if (!layout || !resolvedLayouts['_' + layout]) layout = 'default'
      this.layoutName = layout
      let _layout = '_' + layout
      this.layout = resolvedLayouts[_layout]
      return this.layout
    },
    loadLayout (layout) {
      if (!layout || !(layouts['_' + layout] || resolvedLayouts['_' + layout])) layout = 'default'
      let _layout = '_' + layout
      if (resolvedLayouts[_layout]) {
        return Promise.resolve(resolvedLayouts[_layout])
      }
      return layouts[_layout]()
      .then((Component) => {
        resolvedLayouts[_layout] = Component
        delete layouts[_layout]
        return resolvedLayouts[_layout]
      })
      .catch((e) => {
        if (this.$nuxt) {
          return this.$nuxt.error({ statusCode: 500, message: e.message })
        }
      })
    }
  },
  components: {
    NuxtLoading
  }
}

