importScripts('/_nuxt/workbox.3de3418b.js')

const workboxSW = new self.WorkboxSW({
  "cacheId": "nuxt",
  "clientsClaim": true,
  "directoryIndex": "/"
})

workboxSW.precache([
  {
    "url": "/_nuxt/app.84e2d31271de69fa8c85.js",
    "revision": "04add8b34206b3e1faa9abf46e510ffb"
  },
  {
    "url": "/_nuxt/app.d3d08f4a20090ca8e805725be1c29a18.css",
    "revision": "d3d08f4a20090ca8e805725be1c29a18"
  },
  {
    "url": "/_nuxt/layouts/default.a7ea123df094847120f4.js",
    "revision": "effbafd1018e3facef7989ec71499372"
  },
  {
    "url": "/_nuxt/manifest.f31df5fd067ab6aa3f5d.js",
    "revision": "8a384fe70fd933e2a5250a4149559980"
  },
  {
    "url": "/_nuxt/pages/contact.57af117c1cda9d37c118.js",
    "revision": "93ba5487372067ca0628c822a64d8c11"
  },
  {
    "url": "/_nuxt/pages/index.d0ac137baa10b2a4295f.js",
    "revision": "c70922ffedb23ec86e3630c8fa695049"
  },
  {
    "url": "/_nuxt/pages/projects.8687826b0d78f3fcf2b7.js",
    "revision": "4a38ee863028ca6a951e18907af3687f"
  },
  {
    "url": "/_nuxt/vendor.1c6dbbd80db8df99c119.js",
    "revision": "e299da5fedcd25676c771f0c0a036946"
  }
])


workboxSW.router.registerRoute(new RegExp('/_nuxt/.*'), workboxSW.strategies.cacheFirst({}), 'GET')

workboxSW.router.registerRoute(new RegExp('/.*'), workboxSW.strategies.networkFirst({}), 'GET')

